# RGB-Mood-Arduino
RGB Mood librairie for arduino "fork" from http://forum.arduino.cc/index.php?topic=90160.0
